import ast
import ctypes as C
from ctypes import wintypes as W
import datetime as dt
import json
import pathlib
import re
import statistics
import threading
import time
import urllib.request

import psutil

ROOT = pathlib.Path(__file__).parent
OUT = ROOT / ('qwen2b-near4096-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir(exist_ok=False)
MODEL, SERVER_PID = 'qwen3.5:2b', 25176
BASE = 'http://127.0.0.1:11434'
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

# Reuse only the already-verified PDH data structures and counter reader.
# Do not import/execute the previous benchmark's top-level requests.
old_tree = ast.parse((ROOT / 'measure-qwen2b-peaks-20261028.py').read_text(encoding='utf-8'))
counter_nodes = [node for node in old_tree.body if isinstance(node, ast.ClassDef) and node.name in ('ValueUnion', 'Value', 'Item', 'GpuCounters')]
exec(compile(ast.Module(body=counter_nodes, type_ignores=[]), 'previous-pdh-reader', 'exec'))
original_paragraphs = next(ast.literal_eval(node.value) for node in old_tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'paragraphs' for target in node.targets))
corpus = original_paragraphs + (ROOT / 'qwen2b-near4096-extra-corpus.txt').read_text(encoding='utf-8').strip().split('\n\n')
assert len(set(corpus)) == len(corpus)


def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def api(path, payload=None):
    request = urllib.request.Request(BASE + path,
        data=None if payload is None else json.dumps(payload).encode(),
        headers={'Content-Type': 'application/json'})
    with OPENER.open(request, timeout=20) as response:
        return json.load(response)


server = psutil.Process(SERVER_PID)
assert server.name().lower() == 'ollama.exe' and server.cmdline()[-1] == 'serve'
server_created = server.create_time()
show = api('/api/show', {'model': MODEL})
model_path = next(line[5:].strip().strip('"') for line in show['modelfile'].splitlines() if line.startswith('FROM '))
assert 'sha256-' in model_path
metadata = {'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'model': MODEL,
    'details': show['details'], 'num_ctx': 4096, 'server_pid': SERVER_PID,
    'server_create_time': server_created, 'model_blob': model_path,
    'before': api('/api/ps'), 'target_interval_ms': 100,
    'target_token_total': '3892..4064 (95.0%..99.2% of 4096)',
    'method': 'Native streaming /api/chat; exact model runner only; unchanged unload policy and caches; calibration reported separately',
    'notes': 'Single request at a time; independent messages, no chat history; num_ctx=4096, temperature=0.2, think=false; keep_alive omitted. No 35B requests.'}
save('metadata.json', metadata)
print('OUTPUT ' + str(OUT), flush=True)
stop = threading.Event()
state = {'phase': 'baseline', 'round': 0}
samples, requests, runners, sampling_errors = [], [], {}, []
start = time.perf_counter()


def discover_runner():
    matches = []
    for process in server.children():
        try:
            args = process.cmdline()
            if process.name().lower() == 'llama-server.exe' and '--model' in args and pathlib.Path(args[args.index('--model')+1]) == pathlib.Path(model_path):
                matches.append(process)
        except psutil.NoSuchProcess:
            pass
    if len(matches) > 1:
        raise RuntimeError('Ambiguous model runner')
    if not matches:
        return None
    process = matches[0]
    args = process.cmdline()
    assert args[args.index('-c')+1] == '4096'
    runners[process.pid] = {'pid': process.pid, 'parent_pid': process.ppid(), 'created': process.create_time(), 'args': args}
    return process


def monitor():
    counters = None
    try:
        counters = GpuCounters()
        process = None
        with (OUT / 'samples.jsonl').open('w', encoding='utf-8', buffering=1) as handle:
            while not stop.is_set():
                tick = time.perf_counter()
                # Keep the established process handle, avoiding repeated enumeration
                # and command-line reads on the high-frequency sampling path.
                if process is None:
                    process = discover_runner()
                row = {'elapsed_s': tick-start, 'phase': state['phase'], 'round': state['round'], 'pid': process.pid if process else None}
                if process:
                    try:
                        memory = process.memory_info()
                        row.update(rss=memory.rss, private=memory.private, lifetime_peak_wset=memory.peak_wset,
                            ram_elapsed_s=time.perf_counter()-start)
                        gpu = counters.sample(process.pid)
                        row.update(gpu_elapsed_s=time.perf_counter()-start, gpu_instances=gpu)
                        if gpu:
                            for metric in ['dedicated', 'shared', 'committed']:
                                row['gpu_'+metric] = sum(instance.get(metric, 0) for instance in gpu.values())
                    except psutil.NoSuchProcess:
                        process = None
                else:
                    counters.sample(-1)
                row['sample_cost_ms'] = (time.perf_counter()-tick)*1000
                samples.append(row)
                handle.write(json.dumps(row)+'\n')
                stop.wait(max(0, 0.1-(time.perf_counter()-tick)))
    except Exception as error:
        sampling_errors.append(repr(error))
        print('SAMPLER ERROR ' + repr(error), flush=True)
    finally:
        if counters:
            counters.close()


def build_source(target_words):
    parts, words = [], 0
    for paragraph in corpus:
        selected = []
        for sentence in re.split(r'(?<=[.!?])\s+', paragraph):
            selected.append(sentence)
            words += len(sentence.split())
            if words >= target_words:
                break
        parts.append(f'[P{len(parts)+1:02d}] ' + ' '.join(selected))
        if words >= target_words:
            break
    if words < target_words:
        raise RuntimeError('Not enough unique corpus text')
    return '\n\n'.join(parts)


def translate(source, limit, phase, number):
    if sampling_errors:
        raise RuntimeError(sampling_errors)
    assert server.is_running() and server.create_time() == server_created
    state.update(phase=phase, round=number)
    payload = {'model': MODEL, 'stream': True, 'think': False,
        'messages': [
            {'role': 'system', 'content': 'Translate every numbered paragraph of the English text into Simplified Chinese. Keep every [Pxx] marker and its order. Preserve all details and paragraph breaks. Do not summarize, omit paragraphs, repeat the source, or add explanations. Output only the translation.'},
            {'role': 'user', 'content': source}],
        'options': {'num_ctx': 4096, 'temperature': 0.2, 'num_predict': limit}}
    record = {'phase': phase, 'round': number, 'input_words': len(source.split()),
        'request': payload, 'start_s': time.perf_counter()-start, 'first_text_s': None,
        'chunks': 0, 'output': '', 'thinking_chars': 0}
    requests.append(record)
    print(f'{phase.upper()} {number} START words={record["input_words"]} output_limit={limit}', flush=True)
    request = urllib.request.Request(BASE+'/api/chat', data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
    chunks, final = [], None
    with OPENER.open(request, timeout=180) as response:
        record['http_status'] = response.status
        for line in response:
            if not line.strip():
                continue
            chunk = json.loads(line)
            if chunk.get('error'):
                raise RuntimeError(chunk['error'])
            content = chunk.get('message', {}).get('content', '')
            if content:
                if record['first_text_s'] is None:
                    record['first_text_s'] = time.perf_counter()-start
                chunks.append(content)
                record['chunks'] += 1
            record['thinking_chars'] += len(chunk.get('message', {}).get('thinking', ''))
            if chunk.get('done'):
                final = chunk
    record.update(end_s=time.perf_counter()-start, output=''.join(chunks), final=final)
    assert final and final.get('done') and chunks
    record['input_tokens'] = final['prompt_eval_count']
    record['output_tokens'] = final['eval_count']
    record['total_tokens'] = record['input_tokens']+record['output_tokens']
    record['context_percent'] = record['total_tokens']/4096*100
    record['near_full'] = 3892 <= record['total_tokens'] <= 4064
    record['markers_expected'] = re.findall(r'\[P\d{2}\]', source)
    record['markers_output'] = re.findall(r'\[P\d{2}\]', record['output'])
    record['all_markers_in_order'] = record['markers_expected'] == record['markers_output']
    record['ollama_ps'] = api('/api/ps')
    loaded = next(item for item in record['ollama_ps']['models'] if item['name'] == MODEL)
    assert loaded['context_length'] == 4096
    assert record['thinking_chars'] == 0
    save('requests.json', requests)
    print(f'{phase.upper()} {number} DONE input={record["input_tokens"]} output={record["output_tokens"]} total={record["total_tokens"]} fill={record["context_percent"]:.2f}% reason={final.get("done_reason")} markers={record["all_markers_in_order"]}', flush=True)
    return record


thread = threading.Thread(target=monitor, daemon=True)
thread.start()
error = None
try:
    time.sleep(2)
    source, prompt_tokens = None, None
    target_words = 1540
    for attempt in range(1, 5):
        source = build_source(target_words)
        probe = translate(source, 1, 'token_probe', attempt)
        prompt_tokens = probe['input_tokens']
        assert prompt_tokens < 3200
        limit = 4096-prompt_tokens-32
        pilot = translate(source, limit, 'calibration', attempt)
        assert pilot['input_tokens'] == prompt_tokens, 'Prompt count changed between identical requests'
        if pilot['near_full'] and pilot['final']['done_reason'] == 'stop':
            break
        if pilot['final']['done_reason'] == 'length':
            target_words = int(target_words*0.97)
        else:
            target_words = int(target_words * 3950/pilot['total_tokens'])
    else:
        raise RuntimeError('Calibration did not find a naturally completed near-full translation in four attempts')
    metadata['selected_input_words'] = len(source.split())
    metadata['selected_prompt_tokens'] = prompt_tokens
    metadata['output_token_limit'] = 4096-prompt_tokens-32
    metadata['main_rounds_planned'] = 6
    save('metadata.json', metadata)
    (OUT / 'translation-source.txt').write_text(source, encoding='utf-8')
    for number in range(1, 7):
        result = translate(source, 4096-prompt_tokens-32, 'main', number)
        assert result['input_tokens'] == prompt_tokens
        assert result['total_tokens'] <= 4064
    state.update(phase='post', round=0)
    time.sleep(5)
except Exception as caught:
    error = repr(caught)
    print('ERROR '+error, flush=True)
finally:
    stop.set()
    thread.join(timeout=10)
    save('requests.json', requests)
    save('runners.json', list(runners.values()))
    metadata.update(finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        after=api('/api/ps'), server_same_pid_and_start=server.is_running() and server.create_time()==server_created,
        error=error, sampling_errors=sampling_errors)
    save('metadata.json', metadata)


def summary(group):
    answer = {'samples': len(group)}
    for key in ['rss', 'private', 'gpu_dedicated', 'gpu_shared', 'lifetime_peak_wset']:
        valid = [row for row in group if key in row]
        if valid:
            peak = max(valid, key=lambda row: row[key])
            answer[key] = {'peak_bytes': peak[key], 'peak_gib': peak[key]/2**30,
                'valid_samples': len(valid), 'phase': peak['phase'], 'round': peak['round'], 'elapsed_s': peak['elapsed_s']}
    intervals = [(b['elapsed_s']-a['elapsed_s'])*1000 for a, b in zip(group, group[1:])]
    if intervals:
        ordered = sorted(intervals)
        answer['interval_ms'] = {'min': min(intervals), 'median': statistics.median(intervals),
            'p95': ordered[int((len(ordered)-1)*0.95)], 'p99': ordered[int((len(ordered)-1)*0.99)],
            'max': max(intervals), 'over_250ms': sum(i>250 for i in intervals), 'over_1000ms': sum(i>1000 for i in intervals)}
    return answer


result = {'all': summary(samples), 'calibration': summary([r for r in samples if r['phase'] in ('calibration', 'token_probe')]),
    'main': summary([r for r in samples if r['phase']=='main']),
    'per_round': {str(i): summary([r for r in samples if r['phase']=='main' and r['round']==i]) for i in range(1, 7)},
    'main_rounds': [{k:r[k] for k in ['round', 'input_tokens', 'output_tokens', 'total_tokens', 'context_percent', 'near_full', 'all_markers_in_order']} | {'done_reason': r['final']['done_reason']} for r in requests if r['phase']=='main'],
    'error': error, 'sampling_errors': sampling_errors}
save('summary.json', result)
print(json.dumps({k:v for k,v in result.items() if k != 'per_round'}, indent=2), flush=True)
print('OUTPUT '+str(OUT), flush=True)
if error or sampling_errors:
    raise SystemExit(1)
