import ctypes as C
from ctypes import wintypes as W
import datetime as dt
import json
import pathlib
import statistics
import subprocess
import sys
import threading
import time
import urllib.request

import psutil

BASE = 'http://127.0.0.1:11434'
MODEL = 'qwen3.5:2b'
SERVER_PID = 25176
ROUND_COUNT = int(sys.argv[1]) if len(sys.argv) > 1 else 12
assert 1 <= ROUND_COUNT <= 48
OUT = pathlib.Path(__file__).parent / ('qwen2b-peaks-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir(exist_ok=False)
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def api(path, payload=None, timeout=15):
    request = urllib.request.Request(BASE + path,
        data=None if payload is None else json.dumps(payload).encode(),
        headers={'Content-Type': 'application/json'})
    with OPENER.open(request, timeout=timeout) as response:
        return json.load(response)


def write_json(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


class ValueUnion(C.Union):
    _fields_ = [('longValue', W.LONG), ('doubleValue', C.c_double), ('largeValue', C.c_longlong), ('wideStringValue', W.LPWSTR)]


class Value(C.Structure):
    _anonymous_ = ('data',)
    _fields_ = [('CStatus', W.DWORD), ('data', ValueUnion)]


class Item(C.Structure):
    _fields_ = [('szName', W.LPWSTR), ('FmtValue', Value)]


class GpuCounters:
    def __init__(self):
        self.dll = C.WinDLL('pdh.dll')
        self.dll.PdhOpenQueryW.argtypes = [W.LPCWSTR, C.c_size_t, C.POINTER(W.HANDLE)]
        self.dll.PdhAddEnglishCounterW.argtypes = [W.HANDLE, W.LPCWSTR, C.c_size_t, C.POINTER(W.HANDLE)]
        self.dll.PdhCollectQueryData.argtypes = [W.HANDLE]
        self.dll.PdhGetFormattedCounterArrayW.argtypes = [W.HANDLE, W.DWORD, C.POINTER(W.DWORD), C.POINTER(W.DWORD), C.c_void_p]
        self.dll.PdhCloseQuery.argtypes = [W.HANDLE]
        self.query = W.HANDLE()
        self.check(self.dll.PdhOpenQueryW(None, 0, C.byref(self.query)))
        self.handles = {}
        for key, label in [('dedicated', 'Dedicated Usage'), ('shared', 'Shared Usage'), ('committed', 'Total Committed')]:
            handle = W.HANDLE()
            self.check(self.dll.PdhAddEnglishCounterW(self.query, '\\GPU Process Memory(*)\\' + label, 0, C.byref(handle)))
            self.handles[key] = handle

    @staticmethod
    def check(status):
        if status != 0:
            raise RuntimeError('PDH error ' + hex(status & 0xffffffff))

    def sample(self, pid):
        self.check(self.dll.PdhCollectQueryData(self.query))
        result = {}
        for key, handle in self.handles.items():
            size, count = W.DWORD(), W.DWORD()
            status = self.dll.PdhGetFormattedCounterArrayW(handle, 0x400, C.byref(size), C.byref(count), None)
            if (status & 0xffffffff) not in (0, 0x800007d2):
                self.check(status)
            if not size.value:
                continue
            buffer = C.create_string_buffer(size.value)
            self.check(self.dll.PdhGetFormattedCounterArrayW(handle, 0x400, C.byref(size), C.byref(count), buffer))
            items = C.cast(buffer, C.POINTER(Item))
            for i in range(count.value):
                item = items[i]
                if item.szName.startswith(f'pid_{pid}_'):
                    if item.FmtValue.CStatus not in (0, 1):
                        raise RuntimeError('Invalid GPU sample status')
                    result.setdefault(item.szName, {})[key] = item.FmtValue.largeValue
        return result

    def close(self):
        self.dll.PdhCloseQuery(self.query)


server = psutil.Process(SERVER_PID)
assert server.name().lower() == 'ollama.exe'
assert server.cmdline()[-1] == 'serve'
server_created = server.create_time()
before = api('/api/ps')
show = api('/api/show', {'model': MODEL})
model_path = next(line[5:].strip().strip('"') for line in show['modelfile'].splitlines() if line.startswith('FROM '))
assert 'sha256-' in model_path
metadata = {
    'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'model': MODEL, 'details': show.get('details'), 'num_ctx': 4096,
    'planned_rounds': ROUND_COUNT,
    'server_pid': SERVER_PID, 'server_create_time': server_created,
    'model_blob': model_path, 'before': before, 'sample_interval_target_ms': 100,
    'interface': '/api/chat (stream=true, think=false)',
    'method': 'psutil RSS/private and Windows PDH GPU Process Memory, exact model runner PID only',
    'note': 'No application UI, no service configuration changes, no explicit model unload or restart. Startup and sequential translation phases recorded separately.',
}
write_json('metadata.json', metadata)
print('OUTPUT ' + str(OUT), flush=True)

stop = threading.Event()
state = {'phase': 'baseline', 'round': 0}
samples, runners, sampler_errors = [], {}, []
t0 = time.perf_counter()


def find_runner():
    matches = []
    for process in server.children():
        try:
            args = process.cmdline()
            if process.name().lower() == 'llama-server.exe' and '--model' in args:
                if pathlib.Path(args[args.index('--model') + 1]) == pathlib.Path(model_path):
                    matches.append(process)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    if len(matches) > 1:
        raise RuntimeError('Multiple runners for this model; attribution ambiguous')
    if not matches:
        return None
    process = matches[0]
    if process.pid not in runners:
        args = process.cmdline()
        assert args[args.index('-c') + 1] == '4096', args
        runners[process.pid] = {'pid': process.pid, 'parent_pid': process.ppid(),
            'create_time': process.create_time(), 'exe': process.exe(), 'command_line': args}
    return process


def sample_loop():
    counters = None
    try:
        counters = GpuCounters()
        process, next_scan = None, 0
        with (OUT / 'samples.jsonl').open('w', encoding='utf-8', buffering=1) as log:
            while not stop.is_set():
                tick = time.perf_counter()
                if tick >= next_scan or process is None:
                    process = find_runner()
                    next_scan = tick + 0.5
                row = {'elapsed_s': round(tick - t0, 6), 'phase': state['phase'], 'round': state['round'], 'pid': process.pid if process else None}
                if process:
                    try:
                        memory = process.memory_info()
                        gpu = counters.sample(process.pid)
                        row.update(rss=memory.rss, private=memory.private, gpu_instances=gpu)
                        if gpu:
                            for metric in ['dedicated', 'shared', 'committed']:
                                row['gpu_' + metric] = sum(item.get(metric, 0) for item in gpu.values())
                    except psutil.NoSuchProcess:
                        process = None
                else:
                    counters.sample(-1)
                samples.append(row)
                log.write(json.dumps(row) + '\n')
                stop.wait(max(0, 0.1 - (time.perf_counter() - tick)))
    except Exception as error:
        sampler_errors.append(repr(error))
        print('SAMPLER ERROR ' + repr(error), flush=True)
    finally:
        if counters:
            counters.close()


paragraphs = [
    'The development team is preparing a desktop translation tool for everyday work. A user can paste an email, select a target language, and read the translation as it appears. The original document must remain available while the result is generated. Clear wording matters more than elaborate explanations. The application should preserve names, numbers, and the order of the paragraphs.',
    'At the community library, volunteers are organizing an exhibition about local history. They have collected letters, maps, and photographs from several families. Each item needs a short description in two languages so visitors can understand its background. The volunteers will review uncertain names together and record the source of every date. The exhibition opens on Saturday morning and continues through the following week.',
    'A research group is comparing the performance of several small language models. Every experiment uses the same input documents and the same context limit. The group records memory use while requests are running, rather than relying only on the size of model files. Results should describe the measurement method, the number of completed requests, and any limits that affect interpretation.',
    'The project manager sent a revised schedule after the weekly meeting. Design review will happen before implementation begins, and integration testing will follow the first working version. If a dependency is delayed, the team will update the schedule and explain which tasks are affected. Short progress notes should describe completed work and remaining problems without changing the agreed scope.',
    'Our neighborhood garden uses rainwater collected from the roof of the community center. During dry weeks, volunteers check the soil before watering the vegetables. A small notebook records planting dates, rainfall, and the condition of each bed. Families are invited to help on Sunday afternoons. Children can learn how roots, sunlight, and insects contribute to healthy plants.',
    'When a customer reports a software problem, the support team first asks for a clear description of the steps that produced it. They compare the expected result with the actual result and check whether the issue can be reproduced. A useful report includes the application version and relevant error messages. Personal information should be removed before diagnostic records are shared.',
]


def source_text(round_index, target_words):
    chunks, count, index = [], 0, round_index
    while count < target_words:
        chunk = paragraphs[index % len(paragraphs)]
        chunks.append(chunk)
        count += len(chunk.split())
        index += 1
    return '\n\n'.join(chunks)


thread = threading.Thread(target=sample_loop, daemon=True)
thread.start()
rounds, error = [], None
try:
    time.sleep(2)
    if sampler_errors:
        raise RuntimeError(sampler_errors)
    for i, words in enumerate(([50, 160, 350, 700] * ((ROUND_COUNT + 3) // 4))[:ROUND_COUNT], 1):
        if sampler_errors:
            raise RuntimeError(sampler_errors)
        assert server.is_running() and server.create_time() == server_created
        state.update(phase='translation', round=i)
        text = source_text(i - 1, words)
        payload = {'model': MODEL, 'stream': True, 'think': False,
            'messages': [
                {'role': 'system', 'content': 'Translate the following English text into Simplified Chinese. Preserve the meaning and paragraph breaks. Output only the translation, with no explanation.'},
                {'role': 'user', 'content': text}],
            'options': {'num_ctx': 4096, 'temperature': 0.2, 'num_predict': 2400}}
        record = {'round': i, 'input_words': len(text.split()), 'request': payload,
            'start_s': time.perf_counter() - t0, 'first_text_s': None, 'chunks': 0}
        rounds.append(record)
        print(f'ROUND {i}/{ROUND_COUNT} START words={record["input_words"]}', flush=True)
        request = urllib.request.Request(BASE + '/api/chat', data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
        output, thinking, final = [], [], None
        with OPENER.open(request, timeout=180) as response:
            record['http_status'] = response.status
            for line in response:
                if not line.strip():
                    continue
                chunk = json.loads(line)
                if chunk.get('error'):
                    raise RuntimeError(chunk['error'])
                content = chunk.get('message', {}).get('content', '')
                if content:
                    if record['first_text_s'] is None:
                        record['first_text_s'] = time.perf_counter() - t0
                    output.append(content)
                    record['chunks'] += 1
                if chunk.get('message', {}).get('thinking'):
                    thinking.append(chunk['message']['thinking'])
                if chunk.get('done'):
                    final = chunk
        record.update(end_s=time.perf_counter() - t0, output=''.join(output), thinking_chars=sum(map(len, thinking)), final=final)
        if not final or final.get('done_reason') != 'stop' or not output:
            raise RuntimeError('Translation did not complete normally: ' + str(final))
        loaded = api('/api/ps')
        record['ollama_ps'] = loaded
        model = next(item for item in loaded['models'] if item['name'] == MODEL)
        assert model['context_length'] == 4096, model
        assert record['thinking_chars'] == 0
        write_json('requests.json', rounds)
        print(f'ROUND {i}/{ROUND_COUNT} DONE duration={record["end_s"]-record["start_s"]:.2f}s prompt={final.get("prompt_eval_count")} generated={final.get("eval_count")}', flush=True)
    state.update(phase='post', round=0)
    time.sleep(5)
except Exception as caught:
    error = repr(caught)
    print('ERROR ' + error, flush=True)
finally:
    stop.set()
    thread.join(timeout=10)
    write_json('requests.json', rounds)
    write_json('runners.json', list(runners.values()))
    metadata.update(finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        after=api('/api/ps'), server_same_pid_and_start=server.is_running() and server.create_time() == server_created,
        error=error, sampler_errors=sampler_errors)
    write_json('metadata.json', metadata)

metrics = ['rss', 'private', 'gpu_dedicated', 'gpu_shared', 'gpu_committed']


def summarize(rows):
    result = {'samples': len(rows)}
    for metric in metrics:
        values = [r for r in rows if metric in r]
        if values:
            peak = max(values, key=lambda r: r[metric])
            result[metric] = {'peak_bytes': peak[metric], 'peak_gib': peak[metric] / 2**30,
                'min_bytes': min(r[metric] for r in values), 'last_bytes': values[-1][metric],
                'peak_elapsed_s': peak['elapsed_s'], 'peak_round': peak['round'], 'valid_samples': len(values)}
    return result


intervals = [b['elapsed_s'] - a['elapsed_s'] for a, b in zip(samples, samples[1:])]
summary = {'all': summarize(samples),
    'translation': summarize([r for r in samples if r['phase'] == 'translation']),
    'rounds_after_first': summarize([r for r in samples if r['phase'] == 'translation' and r['round'] >= 2]),
    'post': summarize([r for r in samples if r['phase'] == 'post']),
    'per_round': {str(i): summarize([r for r in samples if r['round'] == i]) for i in range(1, ROUND_COUNT + 1)},
    'completed_rounds': sum(bool(r.get('final', {}).get('done')) for r in rounds if r.get('final')),
    'elapsed_s': time.perf_counter() - t0,
    'sampling_interval_ms': {'median': statistics.median(intervals) * 1000, 'max': max(intervals) * 1000} if intervals else None,
    'error': error, 'sampler_errors': sampler_errors}
write_json('summary.json', summary)
print(json.dumps({key: value for key, value in summary.items() if key != 'per_round'}, indent=2), flush=True)
print('OUTPUT ' + str(OUT), flush=True)
if error or sampler_errors:
    raise SystemExit(1)
