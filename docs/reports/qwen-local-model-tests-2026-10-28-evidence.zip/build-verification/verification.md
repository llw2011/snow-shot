# Snow Shot 本地 2B 应用侧连接修复验证

> 后续进展：已启动本报告对应的修复版，完成真实桌面 WebView2 / Tauri IPC 的模型检测、对话、流式翻译与输入替换检查。旧工作区 exe 已更新为相同哈希的新产物，并恢复普通启动。请以[最新桌面验收记录](D:/work/snow-shot/.tmp/desktop-2b-verification/report.html)为准。以下保留上一轮构建和测试记录。

日期：2026-10-27。工作区：`D:/work/snow-shot`。

## 新版交付

- [新版 Snow Shot 可执行文件](D:/work/snow-shot/.tmp/deliverables/snow-shot-2b-fix-07fe5f71/snowshot.exe)，同目录包含 `app-icons` 资源。版本号仍为 `0.7.17-beta`，是本地修复构建，未制作 NSIS 安装包或发布更新。
- 文件大小：38,445,056 字节。
- SHA-256：`07FE5F7104C8EDC0054476348AEF2CE24CE8291FBEBA780A29FA3FAAF0E5B4F2`。
- 构建命令：`node scripts/build.mjs tauri --no-bundle -- --locked`。前端构建成功，Cargo 输出 `Finished release profile [optimized]`，原生编译耗时 13 分 10 秒。
- **Tauri 命令最终退出码为 1**：它在完成编译后，将 `release/snow-shot.exe` 重命名为 `release/snowshot.exe` 时遇到访问拒绝。核对发现旧的 `release/snowshot.exe` 仍被 PID 27640 运行。因此没有停止旧进程或覆盖它，而是把本次新生成的 `snow-shot.exe` 与托盘资源放入上述独立交付目录，并将交付文件命名为 `snowshot.exe`。
- 已确认交付文件与本次 Cargo 输出 SHA-256 完全相同；新文件与旧 exe 的大小、修改时间不同；新二进制仍含转义后的 IPv6 scope。
- **请先退出旧版，再运行新版。** 本轮未启动交付 exe，也未覆盖 `C:/Program Files/Snow Shot` 的安装。

## 修复及权限边界

- 保留前一轮 `default.json` 中 IPv6 URLPattern 冒号转义修复及 HTTP scope 回归测试。
- 当前已锁定的 `tauri-plugin-http 2.5.4` 启用 `unsafe-headers`，未升级插件或安装新依赖。
- `src/services/tools/modelFetch.ts` 统一处理模型 HTTP 传输。仅 HTTP/HTTPS 的 `127.0.0.1`、`localhost`、`[::1]` 显式传入空 Origin；插件在 Rust 请求中删除该请求头。本地请求禁止自动重定向。
- 模型列表检测、Ollama 版本/能力读取使用该入口；旧模型探针、对话、单段流式翻译、多段翻译请求经 `appFetch` 使用同一入口。保持插件原有流式传输和取消接口。
- 保留 Headers/Request 中的鉴权头与请求体；错误响应通过副本读取，空 403 或非 JSON 错误不再被 JSON 解析异常掩盖。检测中的 401 与 403 分别提示认证失败和服务拒绝访问。
- URL allow scope 与 TLS 验证设置未扩大。注意：`unsafe-headers` 是插件全局构建特性，允许前端设置原先受限的请求头；回环地址限制在应用请求封装中实现，并非 Rust 插件新增的安全隔离。远端模型请求默认仍由插件添加 WebView Origin。
- 本轮没有配置或重启共享 Ollama，没有覆盖安装目录，没有发布或推送。

## 实际服务验证

复现对照：2B 的 `/v1/models` 不带 Origin 返回 200，带 `Origin: http://tauri.localhost` 返回 403；35B 两种请求均返回 200。

下表使用当前源码打包的 `appFetch`、模型检测、旧探针及已安装的插件 JavaScript 客户端，连接真实服务。测试适配器模拟原生 IPC 和已核对的空 Origin 处理；**不等同于运行新 exe 的 Rust IPC/WebView 或界面验收**。

| 检查 | Qwen 3.5 2B，11434 | Qwen 3.5 35B，11440 |
|---|---|---|
| 检测及旧模型探针 | 通过；Ollama；qwen3.5:2b；读取 thinking/vision 能力 | 通过；llama.cpp；qwen3.5-35b-a3b-turbo64k |
| 实际聊天 SDK（Ant Design XRequest） | 9 个文本增量，首文本 871 ms，总计 1067 ms | 6 个文本增量，首文本 472 ms，总计 712 ms |
| 流式翻译（OpenAI SDK + appFetch） | 13 个文本增量，首文本 786 ms，总计 949 ms | 16 个文本增量，首文本 1084 ms，总计 1599 ms |
| 模型设置页使用的 OpenAI SDK 对话 | 8 个文本增量，首文本 14505 ms，总计 14661 ms | 2 个文本增量，首文本 534 ms，总计 642 ms |

2B 翻译结果：“雪影捕捉屏幕，识别并翻译文字仅需数秒。”

35B 翻译结果：“Snow Shot 可捕获屏幕，识别文字，并在几秒钟内完成翻译。”

这些短句验证连接、返回非空内容及流式增量，不代表翻译质量评估。2B 第一次调用明显较慢，后续调用较快；未据此断言具体加载原因。

原始结果：[model-http-live-results.json](D:/work/snow-shot/.tmp/model-http-live-results.json)。

## 自动化检查

- `pnpm exec tsc --noEmit --incremental false`：通过。
- `pnpm exec biome check --vcs-enabled=true --vcs-use-ignore-file=true .`：371 个文件，通过。
- `pnpm exec biome format --vcs-enabled=true --vcs-use-ignore-file=true .`：371 个文件，通过。使用 Git 忽略项排除 Tauri 自动生成 schema；未把这一结果描述成未经调整的 `pnpm lint`。
- `cargo fmt --manifest-path src-tauri/Cargo.toml --all -- --check`：通过。
- `cargo test --locked --test http_scope`：2/2，通过，覆盖默认/自定义 scope、IPv4/IPv6 与远端 HTTP 边界。
- `pnpm test:model-http`：通过，覆盖回环与远端分类、请求头及参数不变性、Request 请求体与取消信号、Ollama 检测/能力读取、401/403 分类，以及完整响应结束前已交付首个 SDK 流式增量。
- `pnpm test:translation`、`pnpm test:api-config`、`pnpm test:model-services`：通过。
- 打包当前 `appFetch` 的附加测试：空 401/403/500、JSON 403 响应仍可被调用方读取，Headers 形式的认证和语言设置被保留。
- `cargo tree --locked -e features -i tauri-plugin-http` 及 release 插件编译指纹确认启用 `unsafe-headers`；`Cargo.lock` 没有本轮新增的版本变动。
- `git diff --check`：通过。

## 仍需在新版桌面应用确认

1. 退出旧版 Snow Shot 后运行这次生成的 exe，确保没有被旧版单实例进程接管。
2. 在模型服务页重新检测 2B 和 35B，确认均显示已连接；分别执行对话测试与翻译测试。
3. 在 AI 对话工具中选择 2B，确认回复逐步出现；在翻译工具中确认单段文字逐步翻译。再检查 35B 仍正常。
4. 界面取消操作、重复发起请求后的显示状态、多段翻译的实际模型输出尚未做本轮桌面验收；多段协议仅运行了现有回归测试。

浏览器开发预览仍受浏览器的 CORS 限制，不能用它代替原生桌面验证。
